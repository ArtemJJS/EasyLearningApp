create
    definer = root@localhost procedure deleteCourseMark(IN id int)
begin
    SELECT target_id AS count into @targ_id from course_mark where mark_id = id;
    DELETE from course_mark where mark_id = id;
    UPDATE course set avg_mark=(select avg(mark_value) from course_mark where target_id = @targ_id)
    where course_id = @targ_id;
end;

