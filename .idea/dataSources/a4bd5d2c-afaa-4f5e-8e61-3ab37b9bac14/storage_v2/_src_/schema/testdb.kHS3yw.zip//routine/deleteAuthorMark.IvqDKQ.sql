create
    definer = root@localhost procedure deleteAuthorMark(IN id int)
begin
    SELECT target_id AS count into @author_id from author_mark where mark_id = id;
    DELETE from author_mark where mark_id = id;
    UPDATE account set avg_mark=(select avg(mark_value) from author_mark where target_id = @author_id)
    where acc_id = @author_id;
end;

