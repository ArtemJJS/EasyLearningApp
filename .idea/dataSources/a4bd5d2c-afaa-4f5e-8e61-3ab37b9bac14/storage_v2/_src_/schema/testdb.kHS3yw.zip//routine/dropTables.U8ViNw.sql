create
    definer = root@localhost procedure dropTables()
begin
    drop table if exists author_mark;

    drop table if exists course_lesson;

    drop table if exists course_chapter;

    drop table if exists course_mark;

    drop table if exists restore_pass_requests;

    drop table if exists user_payment;

    drop table if exists currency_type;

    drop table if exists payment_codes;

    drop table if exists user_purchased_course;

    drop table if exists account;

    drop table if exists course;

    drop table if exists user_type;


end;

