create
    definer = root@localhost procedure dropTables()
begin
    drop table if exists testdb.author_mark;

    drop table if exists testdb.course_lesson;

    drop table if exists testdb.course_chapter;

    drop table if exists testdb.course_mark;

    drop table if exists testdb.restore_pass_requests;

    drop table if exists testdb.user_payment;

    drop table if exists testdb.currency_type;

    drop table if exists testdb.payment_codes;

    drop table if exists testdb.user_purchased_course;

    drop table if exists testdb.account;

    drop table if exists testdb.course;

    drop table if exists testdb.user_type;


end;

