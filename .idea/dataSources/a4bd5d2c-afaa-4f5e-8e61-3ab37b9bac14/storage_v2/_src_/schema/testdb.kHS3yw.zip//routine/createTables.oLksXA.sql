create
    definer = root@localhost procedure createTables()
begin
    create table course
    (
        course_id int auto_increment
            primary key,
        course_name varchar(750) not null,
        course_author_id int not null,
        course_description text not null,
        course_creation_date date not null,
        course_price decimal(10,2) default 0.00 not null,
        avg_mark decimal(3,2) default 0.00 null,
        course_lesson_amount int default 0 null,
        course_duration bigint default 0 null,
        state int default 2 null,
        course_picture text not null,
        update_img_path text null,
        constraint course_name_UNIQUE
            unique (course_name)
    );

    create table course_chapter
    (
        course_chapter_id int auto_increment
            primary key,
        course_id int not null,
        chapter_name text not null,
        chapter_lesson_amount int default 0 null,
        chapter_duration bigint default 0 null,
        constraint course
            foreign key (course_id) references course (course_id)
    );

    create index id_course_idx
        on course_chapter (course_id);

    create table course_lesson
    (
        lesson_id int auto_increment
            primary key,
        course_chapter_id int not null,
        lesson_name text not null,
        lesson_content_address text null,
        lesson_creation_date date not null,
        lesson_duration bigint default 0 not null,
        constraint id_chapter
            foreign key (course_chapter_id) references course_chapter (course_chapter_id)
    );

    create index id_chapter_idx
        on course_lesson (course_chapter_id);


    create table currency_type
    (
        currensy_id int not null
            primary key,
        currency_name varchar(45) null,
        currency_country_code varchar(45) null
    );

    create table payment_codes
    (
        payment_code int auto_increment,
        payment_description varchar(50) not null,
        constraint payment_codes_payment_code_uindex
            unique (payment_code)
    );

    alter table payment_codes
        add primary key (payment_code);

    create table user_type
    (
        user_type_id int not null,
        user_type_name varchar(45) null,
        constraint user_type_name_UNIQUE
            unique (user_type_name),
        constraint user_type_user_type_id_uindex
            unique (user_type_id)
    );

    alter table user_type
        add primary key (user_type_id);

    create table account
    (
        acc_id int auto_increment
            primary key,
        acc_login varchar(50) not null,
        acc_password varchar(50) not null,
        acc_email text not null,
        acc_name varchar(30) not null,
        acc_surname varchar(30) not null,
        acc_birthdate date not null,
        acc_phone_number varchar(20) null,
        acc_registration_date date null,
        acc_about varchar(500) null,
        new_column int null,
        acc_photo_path text null,
        acc_type int default 0 not null,
        avg_mark decimal(3,2) null,
        acc_balance decimal(12,2) default 0.00 null,
        update_photo_path text null,
        acc_pass_salt text not null,
        constraint login_UNIQUE
            unique (acc_login),
        constraint account___type
            foreign key (acc_type) references user_type (user_type_id)
                on update cascade on delete cascade
    );

    create index `type of user_idx`
        on account (acc_type);

    create table author_mark
    (
        mark_id int auto_increment
            primary key,
        target_id int not null,
        acc_id int not null,
        mark_value tinyint(1) not null,
        mark_comment text null,
        mark_date bigint not null,
        constraint `mark of author`
            foreign key (target_id) references account (acc_id)
                on update cascade on delete cascade,
        constraint `user who marked`
            foreign key (acc_id) references account (acc_id)
                on update cascade on delete cascade
    );

    create index id_author_idx
        on author_mark (target_id);

    create index `user who marked_idx`
        on author_mark (acc_id);

    create table course_mark
    (
        mark_id int auto_increment
            primary key,
        target_id int not null,
        acc_id int not null,
        mark_value tinyint(2) not null,
        mark_comment text null,
        mark_date bigint not null,
        constraint course_marks
            foreign key (target_id) references course (course_id)
                on update cascade on delete cascade,
        constraint `user who marked course`
            foreign key (acc_id) references account (acc_id)
                on update cascade on delete cascade
    );

    create index id_course_idx
        on course_mark (target_id);

    create table restore_pass_requests
    (
        acc_id int not null,
        uuid varchar(100) not null,
        constraint restore_pass_requests_account_acc_id_fk
            foreign key (acc_id) references account (acc_id)
                on update cascade on delete cascade
    );

    create table user_payment
    (
        payment_id int auto_increment
            primary key,
        acc_id int not null,
        course_id int null,
        payment_code int not null,
        payment_amount decimal(10,2) not null,
        payment_date mediumtext not null,
        currency_id int not null,
        payment_description varchar(250) null,
        constraint currency
            foreign key (currency_id) references currency_type (currensy_id)
                on update cascade on delete cascade,
        constraint payment_type_codes
            foreign key (payment_code) references payment_codes (payment_code),
        constraint `user payment`
            foreign key (acc_id) references account (acc_id)
                on update cascade on delete cascade
    );

    create index currency_idx
        on user_payment (currency_id);

    create index id_course_idx
        on user_payment (course_id);

    create index id_user_idx
        on user_payment (acc_id);

    create table user_purchased_course
    (
        user_id int not null,
        course_id int not null,
        constraint `course purchased`
            foreign key (course_id) references course (course_id)
                on update cascade on delete cascade,
        constraint `user buyer`
            foreign key (user_id) references account (acc_id)
                on update cascade on delete cascade
    );

    create index id_course_idx
        on user_purchased_course (course_id);

    create index id_user_idx
        on user_purchased_course (user_id);


    INSERT INTO testDB.user_type (user_type_id, user_type_name) VALUES (3, 'admin');
    INSERT INTO testDB.user_type (user_type_id, user_type_name) VALUES (2, 'author');
    INSERT INTO testDB.user_type (user_type_id, user_type_name) VALUES (0, 'guest');
    INSERT INTO testDB.user_type (user_type_id, user_type_name) VALUES (1, 'student');

    INSERT INTO testDB.account (acc_id, acc_login, acc_password, acc_email, acc_name, acc_surname, acc_birthdate, acc_phone_number, acc_registration_date, acc_about, new_column, acc_photo_path, acc_type, avg_mark, acc_balance, update_photo_path, acc_pass_salt) VALUES (1, 'admin', 'NшОѕЌ‘(з±"’ Фјv-B)c4•ѓвCf;®зр$Г', 'annit@list.ru', 'Tom', 'Jerry', '2000-01-01', '+12312312123123', '2019-08-06', '123123', null, 'default_acc_avatar.png', 3, null, 0.00, '', 'q[43b_f^Gb');
    INSERT INTO testDB.account (acc_id, acc_login, acc_password, acc_email, acc_name, acc_surname, acc_birthdate, acc_phone_number, acc_registration_date, acc_about, new_column, acc_photo_path, acc_type, avg_mark, acc_balance, update_photo_path, acc_pass_salt) VALUES (2, 'Author', '123', 'someemail@some.com', 'Tom', 'Jerry', '2019-06-02', '+1234567890', '2019-06-14', 'ing about user', null, 'default_acc_avatar.png', 2, 0.00, 100, null, '');
    INSERT INTO testDB.account (acc_id, acc_login, acc_password, acc_email, acc_name, acc_surname, acc_birthdate, acc_phone_number, acc_registration_date, acc_about, new_column, acc_photo_path, acc_type, avg_mark, acc_balance, update_photo_path, acc_pass_salt) VALUES (3, 'User', '.�7U‚«—-ЫHЂnЙrц4ҐАј:ДхI<ф…', 'email@tut.by', 'Authorr', 'Author', '2000-01-01', '+12312312123123', '2019-07-26', '012345', null, '29.jpg', 1, 0.00, 100, '', 'vqPd9h3rRa');

    INSERT INTO testDB.course (course_id, course_name, course_author_id, course_description, course_creation_date, course_price, avg_mark, course_lesson_amount, course_duration, state, course_picture, update_img_path) VALUES (1, 'Updated from main course', 2, 'first', '2000-01-01', 4.99, 0.00, 5, 5770, 2, '1.png', '');
    INSERT INTO testDB.course (course_id, course_name, course_author_id, course_description, course_creation_date, course_price, avg_mark, course_lesson_amount, course_duration, state, course_picture, update_img_path) VALUES (2, 'Second Course', 2, 'second', '2019-07-04', 250.99, 0.00, 2, 3724, 0, 'default_course_avatar.png', '');
    INSERT INTO testDB.course (course_id, course_name, course_author_id, course_description, course_creation_date, course_price, avg_mark, course_lesson_amount, course_duration, state, course_picture, update_img_path) VALUES (3, 'third course', 2, 'third', '2019-07-04', 4.99, 0.00, 0, 1000, 2, 'default_course_avatar.png', '');

    INSERT INTO testDB.course_chapter (course_chapter_id, course_id, chapter_name, chapter_lesson_amount, chapter_duration) VALUES (1, 1, 'First chapter', 2, 1299);
    INSERT INTO testDB.course_chapter (course_chapter_id, course_id, chapter_name, chapter_lesson_amount, chapter_duration) VALUES (2, 1, 'Updated chapter name', 3, 4471);
    INSERT INTO testDB.course_chapter (course_chapter_id, course_id, chapter_name, chapter_lesson_amount, chapter_duration) VALUES (3, 2, 'Раздел 1', 1, 1224);
    INSERT INTO testDB.course_chapter (course_chapter_id, course_id, chapter_name, chapter_lesson_amount, chapter_duration) VALUES (4, 2, 'Раздел 2', 1, 2500);

    INSERT INTO testDB.course_lesson (lesson_id, course_chapter_id, lesson_name, lesson_content_address, lesson_creation_date, lesson_duration) VALUES (2, 1, 'lesson 1.1', 'https://drive.google.com/file/d/1iEEp7Yxcta_g6tRhC8b0J_EzTEbvacqi/preview', '2019-06-20', 999);
    INSERT INTO testDB.course_lesson (lesson_id, course_chapter_id, lesson_name, lesson_content_address, lesson_creation_date, lesson_duration) VALUES (4, 2, 'lesson 2.1', 'https://drive.google.com/file/d/1mA4Mi9LwxIo6sHCYM2ec2Bbe_crYaaIi/preview', '2019-06-20', 1534);
    INSERT INTO testDB.course_lesson (lesson_id, course_chapter_id, lesson_name, lesson_content_address, lesson_creation_date, lesson_duration) VALUES (5, 1, 'lesson 1.2', 'https://drive.google.com/file/d/1Hu1dxvQow98-zA4RzDKfRM8jGNc9FyMo/preview', '2019-07-05', 300);
    INSERT INTO testDB.course_lesson (lesson_id, course_chapter_id, lesson_name, lesson_content_address, lesson_creation_date, lesson_duration) VALUES (6, 2, 'lesson 2.2', 'https://drive.google.com/file/d/14YMnWZJAMhkCqFhJI8E40QrYaVpoqAer/preview', '2019-07-05', 1422);
    INSERT INTO testDB.course_lesson (lesson_id, course_chapter_id, lesson_name, lesson_content_address, lesson_creation_date, lesson_duration) VALUES (7, 2, 'lesson 2.3', 'https://drive.google.com/file/d/1iEEp7Yxcta_g6tRhC8b0J_EzTEbvacqi/preview', '2019-07-15', 1515);
    INSERT INTO testDB.course_lesson (lesson_id, course_chapter_id, lesson_name, lesson_content_address, lesson_creation_date, lesson_duration) VALUES (8, 3, 'Первый урок', 'https://drive.google.com/file/d/14YMnWZJAMhkCqFhJI8E40QrYaVpoqAer/preview', '2019-07-15', 1224);
    INSERT INTO testDB.course_lesson (lesson_id, course_chapter_id, lesson_name, lesson_content_address, lesson_creation_date, lesson_duration) VALUES (10, 4, 'Про всякое разное', 'https://drive.google.com/file/d/1iEEp7Yxcta_g6tRhC8b0J_EzTEbvacqi/preview', '2019-07-16', 2500);

#     INSERT INTO testDB.course_mark (mark_id, target_id, acc_id, mark_value, mark_comment, mark_date) VALUES (1, 1, 3, 5, '', 1565007798943);

    INSERT INTO testDB.currency_type (currensy_id, currency_name, currency_country_code) VALUES (1, 'USD', 'some code');

    INSERT INTO testDB.payment_codes (payment_code, payment_description) VALUES (10, 'user buy course by card');
    INSERT INTO testDB.payment_codes (payment_code, payment_description) VALUES (11, 'user buy course from balance');
    INSERT INTO testDB.payment_codes (payment_code, payment_description) VALUES (15, 'user deposit');
    INSERT INTO testDB.payment_codes (payment_code, payment_description) VALUES (20, 'author cash-out');
    INSERT INTO testDB.payment_codes (payment_code, payment_description) VALUES (21, 'author sale course');

    INSERT INTO testDB.user_payment (payment_id, acc_id, course_id, payment_code, payment_amount, payment_date, currency_id, payment_description) VALUES (1, 3, 1, 11, -19.99, '1565091865502', 1, 'Purchasing from balance. Course: 11111');
    INSERT INTO testDB.user_payment (payment_id, acc_id, course_id, payment_code, payment_amount, payment_date, currency_id, payment_description) VALUES (2, 2, 1, 21, 19.99, '1565091865573', 1, 'Sale course: 11111');

    INSERT INTO testDB.user_purchased_course (user_id, course_id) VALUES (3, 1);




end;

