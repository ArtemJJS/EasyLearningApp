create
    definer = root@localhost procedure deleteLesson(IN curr_lesson_id int)
begin
    select @curr_chapter := course_chapter_id from course_lesson where lesson_id = curr_lesson_id;
        
    delete from course_lesson where lesson_id = curr_lesson_id;

    update course_chapter
    set chapter_duration      = (select sum(lesson_duration)
                                 from course_lesson
                                 where course_lesson.course_chapter_id = @curr_chapter),
        chapter_lesson_amount = (select count(*)
                                 from course_lesson
                                 where course_lesson.course_chapter_id = @curr_chapter)
    where course_chapter_id = @curr_chapter;

    select @curr_course := course_id from course_chapter where course_chapter_id = @curr_chapter;

    update course
    set course_duration      = (select sum(chapter_duration)
                                from course_chapter
                                where course_chapter.course_id = @curr_course),
        course_lesson_amount = (select sum(chapter_lesson_amount)
                                from course_chapter
                                where course_chapter.course_id = @curr_course)
    where course_id = @curr_course;

end;

