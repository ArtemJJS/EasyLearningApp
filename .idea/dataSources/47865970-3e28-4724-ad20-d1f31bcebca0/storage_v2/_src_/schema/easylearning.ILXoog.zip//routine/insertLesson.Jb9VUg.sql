create
    definer = root@localhost procedure insertLesson(IN new_chapter_id int, IN new_date text, IN new_name text,
                                                    IN new_path text, IN new_duration mediumtext)
begin
    insert into course_lesson set course_chapter_id = new_chapter_id, lesson_name = new_name,
                                  lesson_content_address = new_path, lesson_creation_date = new_date,
                                  lesson_duration = new_duration;

    update course_chapter
    set chapter_duration      = (select sum(lesson_duration)
                                 from course_lesson
                                 where course_lesson.course_chapter_id = new_chapter_id),
        chapter_lesson_amount = (select count(*)
                                 from course_lesson
                                 where course_lesson.course_chapter_id = new_chapter_id)
    where course_chapter_id = new_chapter_id;

    select @curr_course := course_id from course_chapter where course_chapter_id = new_chapter_id;

    update course
    set course_duration      = (select sum(chapter_duration)
                                from course_chapter
                                where course_chapter.course_id = @curr_course),
        course_lesson_amount = (select sum(chapter_lesson_amount)
                                from course_chapter
                                where course_chapter.course_id = @curr_course)
    where course_id = @curr_course;

end;

